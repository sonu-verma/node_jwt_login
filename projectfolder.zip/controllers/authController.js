const db = require('../config/db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs')
exports.register = (req, res) => {
    let message = false;
    const { name, email, password, confirm_password } = req.body;
    db.query('SELECT EMAIL FROM USERS WHERE EMAIL = ?',[email],async (error, results) => {
        if(results.length > 0){
            message  = 'The email is already register.';
            return res.render('register',{
                message: message
            });
        }else if(password != confirm_password){
            message  = 'Please check password, not matches with confirm password';
            return res.render('register',{
                message: message
            });
        }

        bcrypt.hash(password,10)
            .then(hashedpassword => {
                db.query("INSERT into users set ?", { name:name, email: email, password: hashedpassword }, (error, results) => {
                    if(error){
                        console.log('error => ',error);
                    }else{
                        message  = 'successfully register.';
                        return res.render('register',{
                            message: message
                        });
                    }
                });
            });

    });
    // res.send('form submitted');
}

exports.login = (req, res) => {
    const { email, password } = req.body;
    // let sql = "SELECT email FROM USERS WHERE email ="+"'"+email+"'";
    // console.log(sql);
    let message = '';
    db.query( "SELECT email,password FROM USERS WHERE email = ? ", [email] , async (error, results) => {
        if(error) throw error;
        console.log("result => ", results)
        if(results.length > 0){
            var rows = JSON.parse(JSON.stringify(results[0]));
            bcrypt.compare(password,rows.password, function(err, result){
                if(result){
                        const token = jwt.sign(
                            {
                                email: rows.email,
                                userId: rows.id
                            },
                            process.env.JWT_KEY,
                            {
                                expiresIn: '1h'
                            }
                        );
                    return res.send({
                        message: 'succesffully logged in',
                        token: token
                    });

                }else{
                    message: 'invalid password';
                    return res.send({
                        data: message,
                    });
                }
            });
        }else{
            return res.send({
                data: message,
            });
        }
    });

}